<div class="sonando">
	<span class="suena">Lo que suena: </span>
	<div class="description"><a id="cc_strinfo_song_metanoia" class="cc_streaminfo" href="http://us3.listen2myradio.com:2199/tunein/metanoia.pls">Loading ...</a></div>

</div>
<div class="listens">
	<a href="http://us3.listen2myradio.com:2199/tunein/metanoia.pls"><img class="alignnone wp-image-40" src="http://www.metanoiaradio.com/wp-content/uploads/2015/07/ITunes_Logo.png" alt="ITunes_Logo" width="40" height="40" /></a>
	<a href="http://us3.listen2myradio.com:2199/tunein/metanoia.ram"><img class="alignnone wp-image-41" src="http://www.metanoiaradio.com/wp-content/uploads/2015/07/realplayer.png" alt="realplayer" width="40" height="40" /></a>
	<a href="http://us3.listen2myradio.com:2199/tunein/metanoia.pls"><img class="alignnone wp-image-42" src="http://www.metanoiaradio.com/wp-content/uploads/2015/07/winamp.png" alt="winamp" width="40" height="40" /></a> 
	<a href="http://www.metanoiaradio.com/wp-content/uploads/2015/07/mediaplayer.png"><img class="alignnone wp-image-43" src="http://www.metanoiaradio.com/wp-content/uploads/2015/07/mediaplayer.png" alt="mediaplayer" width="40" height="40" /></a>
</div>