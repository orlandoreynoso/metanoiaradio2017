<div>
	<?php  echo do_shortcode("[metaslider id=2816]");  ?>	
</div>