<div class="m-header">
<div class="container">
	<div class="row">
		<div class="m-h">
			<div class="col-xs-12 col-sm-4 col-md-4">
				<div class="ls">
					<?php logo(); ?>
				</div>					
			</div>
			<div class="col-xs-12  col-sm-8 col-md-8">
				<div class="sm">
					<div class="social">
						<p>Síguenos en: </p>
						<div>
							<a href="https://www.facebook.com/Jesustvguatemala"><i class="fe fa fa-facebook"></i></a>
							<a href="https://twitter.com/canaljesustv"><i class="tw fa fa-twitter"></i></a>
							<a href="https://www.youtube.com/user/JesustvOnline/"><i class="yo fa fa-youtube"></i></a>
						</div>
					</div>
					<div class="teljtv">
						<p><i class="dir fa fa-map-marker"></i> 6av. 39-35 zona 8</p>
						<p><i class="cel fa fa-phone"></i> (502) 2440 - 4032 / (502) 2440 - 4719</p>
					</div>
				</div>					
			</div>
		</div>
	</div>		
</div>
</div>