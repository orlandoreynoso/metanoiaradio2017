</div>	

    <footer>
        <div class="group">
        <p>&nbsp;</p>        
        <p>Desarrollado por: <a href="http://www.orlandoreynoso.com">@orlandoreynoso</a></p>
        </div>   
    </footer>

	<script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/js/bootstrap.min.js'></script>
	<script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/js/jquery-3.1.1.min.js'></script>
	<script src="<?php bloginfo('stylesheet_directory'); ?>/js/prefixfree.min.js"></script>	
	<?php wp_footer(); ?>
</body>
</html>